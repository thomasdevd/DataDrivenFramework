package com.w2a.testcases.automationPratice;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.w2a.base.TestBase;

public class CreateAccountTest extends TestBase {
	
	@Test
	public static void createAccount() throws InterruptedException {
		
		click("login_CSS");
		type("createAccountEmailId_CSS","autoTest07122021@gmail.com");
		/*
		 * WebDriverWait wait = new WebDriverWait(driver, 5000);
		 * wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(
		 * "#email_create"))).sendKeys("autoTest07122021@gmail.com");
		 * //driver.findElement(By.cssSelector("#email_create")).sendKeys(
		 * "autoTest07122021@gmail.com"); //click("submit_create");
		 */	}

}

package com.w2a.testcases;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.Test;


public class WorkWithPropertiesFile {
	
	@Test
	public void workWithPropertiesFile() throws IOException {
		
		try {
					
			FileInputStream fis = new FileInputStream(System.getProperty("user.dir") + "\\src\\test\\resources\\properties\\OR.properties");
			Properties prop = new Properties();
			prop.load(fis);
			System.out.println(prop.getProperty("addCustBtn_CSS"));
			
		}
		catch(FileNotFoundException e) {
			 e.printStackTrace();
		}
		
		
		
	}
	
	
	
	
	
	
	

}
